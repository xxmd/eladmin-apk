package com.h5.game.util;

import android.util.Log;

public class LogUtil {
    public static final String TAG = LogUtil.class.getSimpleName();

    public static int debug(String message) {
        return Log.d(TAG, message);
    }

    public static int info(String message) {
        return Log.i(TAG, message);
    }

    public static int warn(String message) {
        return Log.w(TAG, message);
    }

    public static int error(String message, Throwable throwable) {
        return Log.e(TAG, message, throwable);
    }
}
