package com.h5.game.config;


public class LocalConfigProvider implements ConfigProvider {
    private static final String DL_CHANNEL_ID = "75730001";
    private static final String DL_PRODUCT_NAME = "MG";
    private static final String ADJUST_APP_TOKEN = "1rw6zc6ygfnk";
    private static final String H5_WEBSITE_URL = "https://duq12eykn5acj.cloudfront.net/MakeMoney2/cpijmj/prom7/index.html";

    @Override
    public String getDLChannelId() {
        return DL_CHANNEL_ID;
    }

    @Override
    public String getDLProductName() {
        return DL_PRODUCT_NAME;
    }

    @Override
    public AttributionSDKType getAttributionSDKType() {
        return AttributionSDKType.Adjust;
    }

    @Override
    public String getAdjustAppToken() {
        return ADJUST_APP_TOKEN;
    }

    @Override
    public String getH5WebsiteUrl() {
        return H5_WEBSITE_URL;
    }
}
