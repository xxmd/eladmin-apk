package com.h5.game.component;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.text.TextUtils;
import android.view.ViewGroup;
import android.webkit.DownloadListener;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;

import com.h5.game.util.LogUtil;

public class ProgressWebView extends FrameLayout {
    private WebView innerWebView;

    private ProgressWebViewListener listener;

    public void setListener(ProgressWebViewListener listener) {
        this.listener = listener;
    }

    public ProgressWebView(Context context) {
        super(context);
        initView();
        bindEvent();
    }

    public interface ProgressWebViewListener {
        void onMainFrameError(WebResourceError error);

        void onPageStarted(String url);

        void onPageFinished(String url);
    }

    public void setWebChromeClient(WebChromeClient client) {
        innerWebView.setWebChromeClient(client);
    }

    private void bindEvent() {
        innerWebView.setWebViewClient(new WebViewClient() {
            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                super.onReceivedError(view, request, error);
                if (request.isForMainFrame()) {
                    if (listener != null) {
                        listener.onMainFrameError(error);
                    }
                    LogUtil.debug(String.format("innerWebView onReceivedError: error code is %d, error desc is %s", error.getErrorCode(), error.getDescription()));
                }
            }

            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                super.onPageStarted(view, url, favicon);
                if (listener != null) {
                    listener.onPageStarted(url);
                }
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                if (listener != null) {
                    listener.onPageFinished(url);
                }
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                try {
                    String requestUrl = request.getUrl().toString();
                    if (isHttpUrl(requestUrl)) {
                        return false;
                    } else {
                        handleUnknowUrl(requestUrl);
                        return true;
                    }
                } catch (Exception e) {
                    LogUtil.error("shouldOverrideUrlLoading exception", e);
                }
                return super.shouldOverrideUrlLoading(view, request);
            }
        });
        innerWebView.setDownloadListener(new DownloadListener() {
            @Override
            public void onDownloadStart(String s, String s1, String s2, String s3, long l) {
                handleUnknowUrl(s);
            }
        });
    }

    private void handleUnknowUrl(String url) {
        try {
            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setData(Uri.parse(url));
            getContext().startActivity(intent);
        } catch (Exception e) {
            LogUtil.error("handleUnknowUrl", e);
        }
    }

    private boolean isHttpUrl(String url) {
        if (TextUtils.isEmpty(url)) {
            return false;
        }
        return url.toLowerCase().startsWith("http") || url.toLowerCase().startsWith("https");
    }

    private void initView() {
        innerWebView = initWebView(getContext());
        addView(innerWebView, new LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
    }

    private WebView initWebView(Context context) {
        WebView webView = new WebView(context);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setCacheMode(WebSettings.LOAD_NO_CACHE);
        return webView;
    }

    public void loadUrl(String url) {
        innerWebView.loadUrl(url);
    }

    public void reload() {
        innerWebView.reload();
    }

    public boolean canGoBack() {
        return innerWebView.canGoBack();
    }

    public void goBack() {
        innerWebView.goBack();
    }
}
