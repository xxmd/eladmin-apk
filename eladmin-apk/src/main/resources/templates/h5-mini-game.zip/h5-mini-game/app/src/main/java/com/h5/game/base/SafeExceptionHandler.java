package com.h5.game.base;

import android.os.Looper;
import android.util.Log;

public class SafeExceptionHandler implements Thread.UncaughtExceptionHandler {
    public static final String TAG = SafeExceptionHandler.class.getSimpleName();

    @Override
    public void uncaughtException(Thread t, Throwable e) {
        // 打印异常日志
        Log.e(TAG, "捕获未处理异常", e);

        // 特别处理主线程崩溃的情况
        if (t == Looper.getMainLooper().getThread()) {
            Log.e(TAG, "主线程异常，重启 Looper 防止崩溃");

            try {
                // 让主线程重新进入消息循环，防止程序退出
                while (true) {
                    try {
                        Looper.loop();
                    } catch (Throwable innerE) {
                        Log.e(TAG, "Looper 被中断: ", innerE);
                    }
                }
            } catch (Throwable loopCrash) {
                Log.e(TAG, "恢复失败", loopCrash);
            }
        }
    }
}
