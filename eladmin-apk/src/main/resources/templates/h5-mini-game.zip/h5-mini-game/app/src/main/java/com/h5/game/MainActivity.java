package com.h5.game;


import static android.view.View.INVISIBLE;
import static android.view.View.VISIBLE;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ObjectAnimator;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.ViewGroup;
import android.view.animation.DecelerateInterpolator;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebView;
import android.widget.FrameLayout;

import com.dinuscxj.progressbar.CircleProgressBar;
import com.h5.game.base.BaseActivity;
import com.h5.game.component.ProgressWebView;
import com.h5.game.config.ConfigProvider;
import com.h5.game.config.GlobalDataHolder;

public class MainActivity extends BaseActivity {
    private ProgressWebView progressWebView;
    private AlertDialog errorDialog;
    private CircleProgressBar circleProgressBar;
    private boolean loadSuccess = true;
    private final ConfigProvider configProvider = GlobalDataHolder.getConfigProvider();

    private enum WebViewState {
        LOADING, ERROR, NORMAL
    }

    private void setState(WebViewState state) {
        switch (state) {
            case LOADING:
                circleProgressBar.setVisibility(VISIBLE);
                progressWebView.setVisibility(INVISIBLE);
                visualizeWebViewLoad();
                break;
            case ERROR:
                circleProgressBar.setVisibility(INVISIBLE);
                progressWebView.setVisibility(INVISIBLE);
                showErrorDialog();
                break;
            case NORMAL:
                circleProgressBar.setVisibility(INVISIBLE);
                progressWebView.setVisibility(VISIBLE);
                break;
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        initView();
        bindEvent();
    }

    private void initView() {
        FrameLayout frameLayout = new FrameLayout(this);
        frameLayout.setBackgroundColor(Color.WHITE);

        progressWebView = new ProgressWebView(this);
        frameLayout.addView(progressWebView, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        setContentView(frameLayout);

        circleProgressBar = new CircleProgressBar(this);
        circleProgressBar.setLineWidth(dp2px(12));
        circleProgressBar.setProgressTextSize(70);
        int size = dp2px(200);
        FrameLayout.LayoutParams layoutParams = new FrameLayout.LayoutParams(size, size);
        layoutParams.gravity = Gravity.CENTER;
        frameLayout.addView(circleProgressBar, layoutParams);

        progressWebView.loadUrl(configProvider.getH5WebsiteUrl());
        setState(WebViewState.LOADING);
    }

    private int dp2px(int dp) {
        return (int) (dp * getResources().getDisplayMetrics().density + 0.5f);
    }

    private void visualizeWebViewLoad() {
        circleProgressBar.setVisibility(VISIBLE);
        progressWebView.setVisibility(INVISIBLE);
        circleProgressBar.setProgress(0);
        progressWebView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView view, int newProgress) {
                super.onProgressChanged(view, newProgress);
                // animate process change
                int current = circleProgressBar.getProgress();
                ObjectAnimator animator = ObjectAnimator.ofInt(circleProgressBar, "progress", current, newProgress);
                animator.setDuration(500);
                animator.setInterpolator(new DecelerateInterpolator());
                animator.addListener(new AnimatorListenerAdapter() {
                    @Override
                    public void onAnimationEnd(Animator animation) {
                        if (newProgress >= 99) {
                            progressWebView.postDelayed(new Runnable() {
                                @Override
                                public void run() {
                                    if (isWebViewErrorFixed()) {
                                        setState(WebViewState.NORMAL);
                                    }
                                }
                            }, 500);
                        }
                    }
                });
                animator.start();
            }
        });
    }

    private void bindEvent() {
        progressWebView.setListener(new ProgressWebView.ProgressWebViewListener() {
            @Override
            public void onMainFrameError(WebResourceError error) {
                setState(WebViewState.ERROR);
                loadSuccess = false;
            }

            @Override
            public void onPageStarted(String url) {
                loadSuccess = true;
            }

            @Override
            public void onPageFinished(String url) {
            }
        });
    }

    private boolean isWebViewErrorFixed() {
        return (errorDialog == null || !errorDialog.isShowing()) && loadSuccess;
    }

    private void showErrorDialog() {
        if (errorDialog != null && errorDialog.isShowing()) {
            return;
        }
        errorDialog = new AlertDialog.Builder(this)
                .setTitle(R.string.error_title)
                .setMessage(R.string.error_message)
                .setPositiveButton(R.string.reload, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                        progressWebView.reload();
                        setState(WebViewState.LOADING);
                    }
                })
                .setNegativeButton(R.string.quit, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                        finish();
                        System.exit(0);
                    }
                }).create();
        errorDialog.setCancelable(false);
        errorDialog.show();
        errorDialog.getButton(AlertDialog.BUTTON_POSITIVE).setTextColor(Color.parseColor("#1677ff")); // 蓝色
        errorDialog.getButton(AlertDialog.BUTTON_NEGATIVE).setTextColor(Color.parseColor("#ff4d4f")); // 红色
    }

    @Override
    public void onBackPressed() {
        if (progressWebView != null && progressWebView.canGoBack()) {
            progressWebView.goBack();
        } else {
            super.onBackPressed();
        }
    }
}