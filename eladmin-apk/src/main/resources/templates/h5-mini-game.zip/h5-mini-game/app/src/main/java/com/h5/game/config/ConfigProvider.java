package com.h5.game.config;

public interface ConfigProvider {
    enum AttributionSDKType {
        Adjust, Kochava
    }

    String getDLChannelId();

    String getDLProductName();

    AttributionSDKType getAttributionSDKType();

    String getAdjustAppToken();

    String getH5WebsiteUrl();
}
