package com.h5.game.config;

public class GlobalDataHolder {
    public static ConfigProvider configProvider;

    public static ConfigProvider getConfigProvider() {
        if (configProvider == null) {
            configProvider = new LocalConfigProvider();
        }
        return configProvider;
    }
}
