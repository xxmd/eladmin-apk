# 保留 Adjust SDK 相关类，防止 R8 缩减报错
-keep class com.h5.game.util.LogUtil
-keep class com.adjust.sdk.** { *; }
-dontwarn android.content.pm.PackageManager$ResolveInfoFlags