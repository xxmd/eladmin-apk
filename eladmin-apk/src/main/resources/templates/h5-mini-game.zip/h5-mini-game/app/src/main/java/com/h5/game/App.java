package com.h5.game;

import android.app.Application;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;

import androidx.annotation.NonNull;

import com.adjust.sdk.Adjust;
import com.adjust.sdk.AdjustConfig;
import com.h5.game.base.SafeExceptionHandler;
import com.h5.game.config.ConfigProvider;
import com.h5.game.config.GlobalDataHolder;
import com.h5.game.util.LogUtil;

import org.json.JSONObject;


public class App extends Application {
    private ConfigProvider configProvider = GlobalDataHolder.getConfigProvider();

    @Override
    public void onCreate() {
        super.onCreate();
        Thread.setDefaultUncaughtExceptionHandler(new SafeExceptionHandler());
        initThirdSDK();
    }

    private void initThirdSDK() {
        initDLSDK();
    }

    private void initDLSDK() {
        String dlChannelId = configProvider.getDLChannelId();
        String dlProductName = configProvider.getDLProductName();
        LogUtil.debug(String.format("1. init dl sdk channelId: %s, productName: %s", dlChannelId, dlProductName));
        NNXmTDiZFfzbVfXMZ.NNXmTDiZFfzbVfXMZ.NNXmTDiZFfzbVfXMZ.myZg3drT3EDUue6esy.NNXmTDiZFfzbVfXMZ(this, dlChannelId, dlProductName, new WaterLevelHandler(Looper.getMainLooper()));
    }

    private class WaterLevelHandler extends Handler {
        public WaterLevelHandler(@NonNull Looper looper) {
            super(looper);
        }

        @Override
        public void handleMessage(@NonNull Message msg) {
            super.handleMessage(msg);
            switch (msg.what) {  // 根据消息标识处理
                case Integer.MAX_VALUE:
                    LogUtil.debug(String.format("2. dl water level control result: %s", msg.obj));
                    boolean result = parseProtocolQuantity((String) msg.obj);
                    if (!result) {
                        initAttributeSDK();
                    }
                    break;
            }
        }
    }

    public boolean parseProtocolQuantity(String info) {
        try {
            JSONObject jo = new JSONObject(info);
            boolean quantity = jo.optBoolean("quantity", false);
            return quantity;
        } catch (Throwable e) {
            e.printStackTrace();
        }
        return false;
    }

    private void initAttributeSDK() {
        switch (configProvider.getAttributionSDKType()) {
            case Adjust:
                initAdjustSDK();
                break;
        }
    }

    private void initAdjustSDK() {
        String appToken = configProvider.getAdjustAppToken();
        LogUtil.debug(String.format("3. initAdjustSDK appToken: %s", appToken));
        String environment = AdjustConfig.ENVIRONMENT_PRODUCTION;
        AdjustConfig config = new AdjustConfig(this, appToken, environment);
        Adjust.initSdk(config);
    }
}
